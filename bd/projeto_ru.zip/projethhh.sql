-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 10-Nov-2018 às 00:41
-- Versão do servidor: 10.1.19-MariaDB
-- PHP Version: 5.6.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `projeto_ru`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `fale_conosco`
--

CREATE TABLE `fale_conosco` (
  `id_fale_conosco` int(11) NOT NULL,
  `nome` varchar(50) NOT NULL,
  `email` varchar(30) NOT NULL,
  `telefone` varchar(11) NOT NULL,
  `motivo` int(1) NOT NULL,
  `assunto` varchar(50) NOT NULL,
  `mensagem` varchar(255) NOT NULL,
  `data` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `fale_conosco`
--

INSERT INTO `fale_conosco` (`id_fale_conosco`, `nome`, `email`, `telefone`, `motivo`, `assunto`, `mensagem`, `data`) VALUES
(1, '', 'gabriel_jony@hotmail.com', '1991312256', 0, 'Comida ruim', 'Esse é um teste', '2017-01-19 20:08:43'),
(2, '', 'testando@teste.com', '7456985211', 0, 'mal atendimento', 'Mal atendimento pelos funcionarios', '2017-01-19 20:14:36'),
(3, '', 'manuel@teste.com', '1234567891', 0, 'bem agradavel', 'adsfsdssaxcsacsd', '2017-01-19 20:19:14'),
(4, '', 'pedro@teste.com', '1234567891', 0, 'bom', 'tudo de bom', '2017-01-19 20:24:59'),
(5, '', 'artur@teste.com', '77777777', 0, 'legal', 'testelega', '2017-01-19 20:31:40'),
(6, '', 'fabrio@gmail.com', '12345689', 0, 'ruim', 'este ru serve uma comida ruim', '2017-01-19 20:34:56'),
(7, 'jason', 'jason@gmail.com', '55555555555', 0, 'teste', 'teste', '2017-01-19 20:40:03'),
(8, 'mateus', 'mateus@gmail.com', '888996555', 0, 'sem assunto', 'teste sem assuntro', '2017-01-19 20:48:36'),
(9, 'alex', 'alex@hotmail.com', '78754563213', 3, 'Muito sujo', 'sujeira total', '2017-01-20 08:00:35'),
(10, 'dsfdf', 'sdfsdf', '', 2, 'ssdfsd', 'sdfdfsdf', '2018-11-09 20:38:52');

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuario`
--

CREATE TABLE `usuario` (
  `id_usuario` int(11) NOT NULL,
  `usuario` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `cpf` int(11) DEFAULT NULL,
  `telefone` int(10) DEFAULT NULL,
  `tipo_login` int(1) NOT NULL,
  `num_login` int(10) NOT NULL,
  `tipo_user` int(1) NOT NULL,
  `img` longblob,
  `senha` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `usuario`
--

INSERT INTO `usuario` (`id_usuario`, `usuario`, `email`, `cpf`, `telefone`, `tipo_login`, `num_login`, `tipo_user`, `img`, `senha`) VALUES
(1, 'gabriel', '', NULL, NULL, 0, 0, 0, '', '123456'),
(2, 'Raul', '', NULL, NULL, 0, 0, 0, '', '22b680916381501206988eae437a994e'),
(3, 'Samuel', '', NULL, NULL, 0, 0, 0, '', '202cb962ac59075b964b07152d234b70'),
(4, '', '', NULL, NULL, 0, 0, 0, '', 'd41d8cd98f00b204e9800998ecf8427e');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `fale_conosco`
--
ALTER TABLE `fale_conosco`
  ADD PRIMARY KEY (`id_fale_conosco`);

--
-- Indexes for table `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`id_usuario`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `fale_conosco`
--
ALTER TABLE `fale_conosco`
  MODIFY `id_fale_conosco` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `usuario`
--
ALTER TABLE `usuario`
  MODIFY `id_usuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
